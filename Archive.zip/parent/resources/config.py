quandlapi = 'R1lE9ybkvLYYhI5ER2PSpQiQtsYQjBzN'
